# Titanic Data Analysis

## Dataset
- Source: [Titanic Dataset - Data Science Dojo](https://www.kaggle.com/datasets/shivamb/netflix-shows)
- Contains passenger details and survival info on the Titanic disaster.

## What this project does
- Loads the Titanic dataset using Pandas.
- Cleans missing data (Age column).
- Filters and groups data by class and sex.
- Calculates average age, survival rate, and passenger counts.
- Creates visualizations:
  - Count of survivors vs non-survivors
  - Survival rate by passenger class
  - Age distribution by survival status

## How to run

1. Install dependencies:

```
pip install pandas numpy matplotlib seaborn
```

2. Run the script:

```
python titanic_analysis.py
```

3. Check the current folder for saved plot images:
- `survival_count.png`
- `survival_by_class.png`
- `age_distribution.png`

## Insights
- Passengers in higher classes had better survival rates.
- Age distribution varies between survivors and non-survivors.