import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load Titanic dataset
url = "https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv"
df = pd.read_csv(url)

# Preview data
print("First 5 rows:")
print(df.head())

# Fill missing Age values with median
df['Age'].fillna(df['Age'].median(), inplace=True)

# Filter: passengers who survived
survivors = df[df['Survived'] == 1]

# Group by 'Pclass' and 'Sex' and aggregate average age and survival rate
grouped = df.groupby(['Pclass', 'Sex']).agg({
    'Age': 'mean',
    'Survived': 'mean',
    'PassengerId': 'count'
}).rename(columns={'PassengerId': 'Count'})

print("\nGrouped data (average age, survival rate, count):")
print(grouped)

# Visualization 1: Countplot of survivors vs non-survivors
plt.figure(figsize=(8,5))
sns.countplot(data=df, x='Survived')
plt.title('Count of Survivors (1) and Non-Survivors (0)')
plt.savefig('survival_count.png')
plt.show()

# Visualization 2: Survival rate by passenger class
plt.figure(figsize=(8,5))
sns.barplot(x='Pclass', y='Survived', data=df)
plt.title('Survival Rate by Passenger Class')
plt.savefig('survival_by_class.png')
plt.show()

# Visualization 3: Age distribution by survival status
plt.figure(figsize=(8,5))
sns.histplot(data=df, x='Age', hue='Survived', bins=30, kde=True)
plt.title('Age Distribution by Survival Status')
plt.savefig('age_distribution.png')
plt.show()